These are neutral wordmark-style logo placeholders sized 348x128px with transparent background.
Suggested HTML/CSS inside each tile:
<img src="ibm.png" alt="IBM" style="max-width:80%;max-height:60%;object-fit:contain;" />
